#include "WiFiS3.h"   // Librería WiFi del Arduino UNO R4 WiFi (ya viene incluida)
#include "arduino_secrets.h"

// ====== 1. CAMBIA ESTO POR TU WIFI ======
const char ssid[] = SECRET_SSID;
const char pass[] = SECRET_PASS;
// ========================================

const int soilPin = A0;
const int pumpPin = 9;

// Tipo de planta
// 1 = Bajo consumo de agua
// 2 = Consumo medio
// 3 = Alto consumo de agua
int plantType = 2;

// Umbrales
int onThreshold;
int offThreshold;

bool pumpOn = false;
enum Modo { MODO_APAGADO, MODO_AUTO, MODO_SIEMPRE };
Modo modo = MODO_AUTO;

int soilValue = 0;
unsigned long lastRead = 0;      // para medir el tiempo sin usar delay()
unsigned long lastIpPrint = 0;   // para repetir la IP cada cierto tiempo

WiFiServer server(80);           // servidor web en el puerto 80

void setup() {
  pinMode(pumpPin, OUTPUT);
  digitalWrite(pumpPin, LOW);

  Serial.begin(9600);

  aplicarUmbrales();

  // Conectarse al WiFi
  Serial.print("Conectando a ");
  Serial.println(ssid);

  int status = WL_IDLE_STATUS;
  while (status != WL_CONNECTED) {
    status = WiFi.begin(ssid, pass);
    Serial.println("Intentando conectar...");
    delay(5000);
  }

  // Esperar a que el router entregue una IP válida (máx. 15 segundos)
  int intentos = 0;
  while (WiFi.localIP()[0] == 0 && intentos < 30) {
    delay(500);
    intentos++;
  }

  server.begin();

  Serial.println("¡Conectado!");
  Serial.print("Abre esta direccion en tu navegador: http://");
  Serial.println(WiFi.localIP());
}

// Configurar los umbrales según el tipo de planta
void aplicarUmbrales() {
  switch (plantType) {
    case 1: onThreshold = 750; offThreshold = 600; break;
    case 2: onThreshold = 700; offThreshold = 500; break;
    case 3: onThreshold = 650; offThreshold = 450; break;
  }
  pumpOn = false;
}

void loop() {
  atenderClienteWeb();   // revisa si alguien abrió la página o apretó un botón

  // Cada 10 segundos, repetir la IP por el Serial Monitor
  if (millis() - lastIpPrint >= 10000) {
    lastIpPrint = millis();
    Serial.print("IP actual: ");
    Serial.println(WiFi.localIP());
  }

  // Cada 1 segundo, leer el sensor (reemplaza al delay(1000) de antes)
  if (millis() - lastRead >= 1000) {
    lastRead = millis();
    controlarRiego();
  }
}

void controlarRiego() {
  switch (modo) {
    case MODO_APAGADO:
      pumpOn = false;
      digitalWrite(pumpPin, LOW);
      Serial.println("SISTEMA: DESACTIVADO");
      Serial.println("BOMBA: APAGADA");
      soilValue = -1;          
      return;                  
    case MODO_SIEMPRE:
      pumpOn = true;
      digitalWrite(pumpPin, HIGH);
      Serial.println("BOMBA: ENCENDIDA");
      soilValue = -1;
      return;                  // ignora el sensor
    case MODO_AUTO:
      break;
  }

  soilValue = analogRead(soilPin);

  Serial.print("Humedad: ");
  Serial.println(soilValue);

  if (soilValue > onThreshold)       pumpOn = true;
  else if (soilValue < offThreshold) pumpOn = false;
  digitalWrite(pumpPin, pumpOn ? HIGH : LOW);
  if (pumpOn) {
    Serial.println("BOMBA: ENCENDIDA");
  } else {
    Serial.println("BOMBA: APAGADA");
  }
}

void atenderClienteWeb() {
  WiFiClient client = server.available();
  if (!client) return;

  String request = "";
  String currentLine = "";
  unsigned long start = millis();

  while (client.connected() && millis() - start < 500) {

    if (client.available()) {
      char c = client.read();
      request += c;

      if (c == '\n') {

        // Detectamos el final de las cabeceras HTTP
        if (currentLine.length() == 0) {

          // Extraemos solamente la primera línea
          String linea = request.substring(0, request.indexOf('\n'));

          // Validación del token de acceso
          String tokenEsperado = String("key=") + SECRET_TOKEN;

          if (linea.indexOf(tokenEsperado) < 0) {
          
            client.println("HTTP/1.1 401 Unauthorized");
            client.println("Content-Type: text/plain; charset=utf-8");
            client.println("Connection: close");
            client.println();
            client.println("Acceso denegado: token incorrecto.");
          
            break;
          }

          bool rutaValida = true;

          // MODOS DE FUNCIONAMIENTO
          if (linea.startsWith("GET /modo/apagado")) {
            modo = MODO_APAGADO;
          }
          else if (linea.startsWith("GET /modo/auto")) {
            modo = MODO_AUTO;
          }
          else if (linea.startsWith("GET /modo/siempre")) {
            modo = MODO_SIEMPRE;
          }

          // TIPOS DE PLANTA
          else if (linea.startsWith("GET /planta/1")) {
            plantType = 1;
            aplicarUmbrales();
          }
          else if (linea.startsWith("GET /planta/2")) {
            plantType = 2;
            aplicarUmbrales();
          }
          else if (linea.startsWith("GET /planta/3")) {
            plantType = 3;
            aplicarUmbrales();
          }

          // CONSULTA DEL ESTADO
          else if (linea.startsWith("GET /estado")) {
            // No modificamos nada.
          }

          // PANEL HTML
          else if (linea.startsWith("GET / ")) {
            enviarPagina(client);
            break;
          }

          // RUTA DESCONOCIDA
          else {
            rutaValida = false;

            client.println("HTTP/1.1 404 Not Found");
            client.println("Connection: close");
            client.println();
            break;
          }

          if (rutaValida) {
            // Aplicar inmediatamente los cambios
            controlarRiego();

            // Responder con el estado actualizado
            enviarEstadoJson(client);
            break;
          }
        }

        currentLine = "";
      }
      else if (c != '\r') {
        currentLine += c;
      }
    }
  }

  client.stop();
}

void enviarEstadoJson(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: application/json; charset=utf-8");
  client.println("Connection: close");
  client.println();
  client.print("{\"modo\":");    client.print((int)modo);
  client.print(",\"planta\":");  client.print(plantType);
  client.print(",\"humedad\":"); client.print(soilValue);
  client.print(",\"bomba\":");   client.print(pumpOn ? "true" : "false");
  client.print(",\"on\":");      client.print(onThreshold);
  client.print(",\"off\":");     client.println(offThreshold);
  client.println("}");
}

void enviarPagina(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html; charset=utf-8");
  client.println("Connection: close");
  client.println();

  client.println("<!DOCTYPE html><html><head>");
  client.println("<meta charset='utf-8'>");
  client.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
  client.println("<meta http-equiv='refresh' content='3'>");   // se actualiza cada 3 s
  client.println("<title>Riego automático</title>");
  client.println("<style>");
  client.println("body{font-family:Arial;text-align:center;margin-top:40px;}");
  client.println("a.btn{display:inline-block;padding:18px 30px;margin:10px;font-size:20px;");
  client.println("color:white;text-decoration:none;border-radius:8px;}");
  client.println(".on{background:#2e8b57;} .off{background:#c0392b;}");
  client.println("</style></head><body>");

  client.println("<h1>Riego automático</h1>");

  client.print("<p>Humedad (sensor): <b>");
  if (soilValue == -1) {
    client.print("No disponible");
  } else {
    client.print(soilValue);
  }
  client.println("</b></p>");

  client.print("<p>Sistema: <b>");
  client.print(modo == MODO_APAGADO ? "DESACTIVADO" : "ACTIVADO");
  client.println("</b></p>");

  client.print("<p>Bomba: <b>");
  client.print(pumpOn ? "ENCENDIDA" : "APAGADA");
  client.println("</b></p>");

  client.print("<p>Tipo de planta: <b>");
  switch (plantType) {
    case 1:
      client.print("Bajo consumo de agua");
      break;
    case 2:
      client.print(" Consumo medio de agua");
      break;
    case 3:
      client.print("Alto consumo de agua");
      break;
  }
client.println("</b></p>");

  client.print("<p>Umbral de encendido: ");
  client.print(onThreshold);
  client.println("</p>");
  client.print("<p>Umbral de apagado: ");
  client.print(offThreshold);
  client.println("</p>");

  client.println("<h2>Modos de funcionamiento</h2>");

  client.print("<a class='btn off' href='/modo/apagado?key=");
  client.print(SECRET_TOKEN);
  client.println("'>APAGADO</a>");

  client.print("<a class='btn on' href='/modo/auto?key=");
  client.print(SECRET_TOKEN);
  client.println("'>AUTOMÁTICO</a>");

  client.print("<a class='btn on' href='/modo/siempre?key=");
  client.print(SECRET_TOKEN);
  client.println("'>SIEMPRE ENCENDIDO</a>");
  
  client.println("<h2>Tipo de planta</h2>");
  
  client.println("<a class='btn on' href='/planta/1'>PLANTA BAJO CONSUMO</a>");
  client.println("<a class='btn on' href='/planta/2'>PLANTA CONSUMO MEDIO</a>");
  client.println("<a class='btn on' href='/planta/3'>PLANTA ALTO CONSUMO</a>");

  client.println("</body></html>");
}
