package com.example.sistema_riego.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirestoreRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    suspend fun saveReading(data: SensorData) {

        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("Usuario no autenticado")

        val reading = hashMapOf(
            "humidity" to data.humidity,
            "pump" to data.pump,
            "mode" to data.mode,
            "plant" to data.plant,
            "timestamp" to System.currentTimeMillis()
        )

        db.collection("users")
            .document(uid)
            .collection("readings")
            .add(reading)
            .await()
    }
}