package com.example.sistema_riego.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ArduinoApi(
    private val ip: String,
    private val token: String = ""
) {

    private suspend fun get(path: String): SensorData = withContext(Dispatchers.IO) {
        val url = URL("http://$ip$path?key=$token")
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 3000
            connection.readTimeout = 3000
            connection.setRequestProperty("Accept", "application/json")

            val code = connection.responseCode
            if (code !in 200..299) throw Exception("Error HTTP: $code")

            val text = connection.inputStream.bufferedReader().use { it.readText() }
            parse(JSONObject(text))
        } finally {
            connection.disconnect()
        }
    }

    private fun parse(j: JSONObject) = SensorData(
        humidity = j.optInt("humedad", -1),
        pump = j.optBoolean("bomba", false),
        mode = when (j.optInt("modo", 0)) { 1 -> "AUTO"; 2 -> "ALWAYS"; else -> "OFF" },
        plant = when (j.optInt("planta", 2)) { 1 -> "LOW"; 3 -> "HIGH"; else -> "MEDIUM" }
    )

    suspend fun getStatus(): SensorData = get("/estado")

    suspend fun setMode(mode: String): SensorData = get(
        when (mode) { "AUTO" -> "/modo/auto"; "ALWAYS" -> "/modo/siempre"; else -> "/modo/apagado" }
    )

    suspend fun setPlant(plant: String): SensorData = get(
        when (plant) { "LOW" -> "/planta/1"; "HIGH" -> "/planta/3"; else -> "/planta/2" }
    )
}