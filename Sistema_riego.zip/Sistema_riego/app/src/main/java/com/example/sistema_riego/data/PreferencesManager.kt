package com.example.sistema_riego.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class PreferencesManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val preferences =
        EncryptedSharedPreferences.create(
            context,
            "secure_preferences",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    fun saveArduinoIp(ip: String) {
        preferences.edit()
            .putString("arduino_ip", ip)
            .apply()
    }

    fun getArduinoIp(): String {
        return preferences.getString(
            "arduino_ip",
            ""
        ) ?: ""
    }

    fun saveArduinoToken(token: String) {
        preferences.edit()
            .putString("arduino_token", token)
            .apply()
    }

    fun getArduinoToken(): String {
        return preferences.getString(
            "arduino_token",
            ""
        ) ?: ""
    }
}