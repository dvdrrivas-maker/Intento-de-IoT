package com.example.sistema_riego.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sistema_riego.data.ArduinoApi
import com.example.sistema_riego.data.SensorData
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModelProvider
import com.example.sistema_riego.data.FirestoreRepository
import kotlin.time.Duration.Companion.milliseconds

class MainViewModelFactory(
    private val api: ArduinoApi
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(
        modelClass: Class<T>
    ): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(api) as T
        }

        throw IllegalArgumentException("ViewModel desconocido")
    }
}

class MainViewModel(
    private val api: ArduinoApi
) : ViewModel() {

    private val repository = FirestoreRepository()

    private val _sensor = MutableStateFlow(SensorData())
    val sensor: StateFlow<SensorData> = _sensor.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    init {
        startPolling()
        startSavingReadings()
    }

    private fun startPolling() {
        viewModelScope.launch {
            while (true) {
                try {
                    _sensor.value = api.getStatus()
                    _error.value = null
                } catch (e: Exception) {
                    _error.value = "No se pudo conectar con Arduino"
                } finally {
                    _loading.value = false
                }

                delay(2000.milliseconds)
            }
        }
    }

    fun changeMode(mode: String) {
        viewModelScope.launch {
            try {
                api.setMode(mode)
                _error.value = null
            } catch (e: Exception) {
                _error.value = "No se pudo cambiar el modo"
            }
        }
    }

    fun changePlant(plant: String) {
        viewModelScope.launch {
            try {
                api.setPlant(plant)
                _error.value = null
            } catch (e: Exception) {
                _error.value = "No se pudo cambiar la planta"
            }
        }
    }
    private fun startSavingReadings() {
        viewModelScope.launch {
            while (true) {
                delay(20_000)
                if (_loading.value || _error.value != null) continue   // sin conexión: no guardar

                try {
                    repository.saveReading(_sensor.value)
                } catch (e: Exception) {
                    _error.value = "No se pudo guardar el historial"
                }
            }
        }
    }
}


