package com.example.sistema_riego.data

data class SensorData(
    val humidity: Int = 0,
    val pump: Boolean = false,
    val mode: String = "OFF",
    val plant: String = "MEDIUM"
)